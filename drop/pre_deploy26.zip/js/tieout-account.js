/* TieOut Canvas accounts: Wix member sign-in (OAuth PKCE via Wix-managed login),
   plan checkout (Wix Pricing Plans), and the current subscriber's plan.
   Tokens live in this browser only (localStorage "tieout_member"). */
(function(){
const API="https://www.wixapis.com";
const CLIENT="4a63c9c7-e140-4696-8b8e-a36256160389";
const KEY="tieout_member", PKCE="tieout_pkce", VIS="tieout_visitor";
const PLANS={
  "24e4aafa-5b5f-4c14-ad39-811b90644b69":{tier:"pro",label:"Pro",cycle:"monthly"},
  "bded847d-ebd3-4c22-b40a-ba4921bf3b78":{tier:"pro",label:"Pro",cycle:"yearly"},
  "b80b7e89-44d1-4c4c-983f-25e4ffe3c9f1":{tier:"pro",label:"Pro",cycle:"launch offer"},
  "1e5599ef-e68e-4cd1-a132-3b493011e825":{tier:"team",label:"Team",cycle:"monthly"},
  "99680b34-308f-43d3-a9df-6783375c204f":{tier:"team",label:"Team",cycle:"yearly"}
};
const get=k=>{try{return JSON.parse(localStorage.getItem(k)||"null")}catch(e){return null}};
const put=(k,v)=>{try{v==null?localStorage.removeItem(k):localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const SITE="https://www.revreccanvas.com",AI="https://tieout-ai.gentle-thunder-4dd2.workers.dev";
const onSite=()=>/^https?:$/.test(location.protocol)&&/(^|\.)revreccanvas\.com$/.test(location.hostname);
const here=()=>(onSite()?location.origin:SITE)+"/account.html";
function b64url(buf){return btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
function rand(n){const a=new Uint8Array(n);crypto.getRandomValues(a);return b64url(a)}
async function post(path,body,token){
  const h={"Content-Type":"application/json"};if(token)h.Authorization=token;
  const r=await fetch(API+path,{method:"POST",headers:h,body:JSON.stringify(body)});
  const d=await r.json().catch(()=>({}));if(!r.ok){const e=new Error((d&&(d.message||d.error_description||d.error))||("HTTP "+r.status));e.status=r.status;e.data=d;throw e}return d}
async function getJ(path,token){
  const r=await fetch(API+path,{headers:{Authorization:token}});
  const d=await r.json().catch(()=>({}));if(!r.ok){const e=new Error((d&&d.message)||("HTTP "+r.status));e.status=r.status;throw e}return d}
function save(t){const v={access:t.access_token,refresh:t.refresh_token,exp:Date.now()+((t.expires_in||14400)-120)*1000};return v}
async function visitor(){
  let v=get(VIS);
  if(v&&v.exp>Date.now())return v.access;
  try{const t=v&&v.refresh?await post("/oauth2/token",{clientId:CLIENT,grantType:"refresh_token",refreshToken:v.refresh}):await post("/oauth2/token",{clientId:CLIENT,grantType:"anonymous"});v=save(t);put(VIS,v);return v.access}
  catch(e){const t=await post("/oauth2/token",{clientId:CLIENT,grantType:"anonymous"});v=save(t);put(VIS,v);return v.access}}
async function member(){
  let m=get(KEY);if(!m)return null;
  if(m.exp>Date.now())return m.access;
  try{const t=await post("/oauth2/token",{clientId:CLIENT,grantType:"refresh_token",refreshToken:m.refresh});const n=save(t);n.email=m.email;put(KEY,n);return n.access}
  catch(e){put(KEY,null);return null}}
async function signIn(after){
  const verifier=rand(48),state=rand(16);
  const challenge=b64url(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(verifier)));
  put(PKCE,{verifier,state,after:after||"",at:Date.now()});
  const body={auth:{authRequest:{redirectUri:here(),clientId:CLIENT,codeChallenge:challenge,codeChallengeMethod:"S256",responseMode:"fragment",responseType:"code",scope:"offline_access",state}}};
  const d=await post("/_api/redirects-api/v1/redirect-session",body,await visitor());
  location.href=d.redirectSession.fullUrl}
async function finishSignIn(){
  const h=new URLSearchParams(location.hash.slice(1));if(!h.get("code")&&!h.get("error"))return null;
  history.replaceState(null,"",location.pathname+location.search);
  if(/^dev\./.test(h.get("state")||"")){ /* sign-in started by the desktop app: hand the one-time code to it */
    if(h.get("error"))throw new Error(h.get("error_description")||h.get("error"));
    const r=await fetch(AI+"/v1/link/put",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({state:h.get("state"),code:h.get("code")})});
    if(!r.ok)throw new Error("Couldn't pass the sign-in to your desktop app. Try again from the app.");return "desktop"}
  const p=get(PKCE);put(PKCE,null);
  if(h.get("error"))throw new Error(h.get("error_description")||h.get("error"));
  if(!p||p.state!==h.get("state"))throw new Error("The sign-in link expired. Try signing in again.");
  const t=await post("/oauth2/token",{clientId:CLIENT,grantType:"authorization_code",redirectUri:here(),code:h.get("code"),codeVerifier:p.verifier});
  put(KEY,save(t));return p.after||"done"}
function signOut(){put(KEY,null)}
/* Desktop app: open the sign-in in the person's browser, then collect the one-time code from the AI service. */
async function signInDesktop(opts){opts=opts||{};
  const inv=window.__TAURI__&&window.__TAURI__.core&&window.__TAURI__.core.invoke;if(!inv)throw new Error("This sign-in is for the desktop app.");
  const verifier=rand(48),state="dev."+rand(24);
  const challenge=b64url(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(verifier)));
  const body={auth:{authRequest:{redirectUri:here(),clientId:CLIENT,codeChallenge:challenge,codeChallengeMethod:"S256",responseMode:"fragment",responseType:"code",scope:"offline_access",state}}};
  const d=await post("/_api/redirects-api/v1/redirect-session",body,await visitor());
  await inv("open_url",{url:d.redirectSession.fullUrl});
  const until=Date.now()+10*60*1000;
  while(Date.now()<until){if(opts.cancelled&&opts.cancelled())return false;
    await new Promise(r=>setTimeout(r,2000));
    let x={};try{const r=await fetch(AI+"/v1/link/take",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({state})});x=await r.json()}catch(e){continue}
    if(x.pending)continue;if(!x.code)throw new Error("That sign-in link was already used. Try again.");
    const t=await post("/oauth2/token",{clientId:CLIENT,grantType:"authorization_code",redirectUri:here(),code:x.code,codeVerifier:verifier});
    put(KEY,save(t));try{await me()}catch(e){}return true}
  throw new Error("Sign-in timed out. Try again.")}
async function aiUsage(){const t=await member();if(!t)return null;
  const r=await fetch(AI+"/v1/me",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({memberToken:t})});return r.json()}
async function me(){const t=await member();if(!t)return null;
  const d=await getJ("/members/v1/members/my?fieldsets=FULL",t);const m=d.member||{};
  const email=m.loginEmail||(m.contact&&m.contact.emails&&m.contact.emails[0])||"";
  const s=get(KEY);if(s){s.email=email;put(KEY,s)}return {id:m.id,email}}
async function orders(){const t=await member();if(!t)return [];
  const d=await getJ("/pricing-plans/v2/member/orders?limit=50",t);return d.orders||[]}
async function plan(){
  const os=(await orders()).filter(o=>PLANS[o.planId]&&o.status==="ACTIVE");
  if(os.length){const team=os.find(o=>PLANS[o.planId].tier==="team");const o=team||os[0];
    if(team)aiUsage().catch(()=>{}); /* keeps the team's seats current */
    return {tier:PLANS[o.planId].tier,label:PLANS[o.planId].label,cycle:PLANS[o.planId].cycle,order:o,admin:!!team}}
  let u=null;try{u=await aiUsage()}catch(e){}
  if(u&&u.ok&&u.kind==="team-seat")return {tier:"team",label:"Team",cycle:"team member",order:null,seat:true};
  return null}
async function teamCall(path,extra){const t=await member();if(!t)throw new Error("Sign in first.");
  const r=await fetch(AI+"/v1/team/"+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.assign({memberToken:t},extra||{}))});
  const d=await r.json().catch(()=>({}));if(!r.ok||!d.ok)throw new Error(d.message||"Couldn't update your team. Try again.");return d}
async function checkout(planId){
  const t=(await member())||await visitor();
  const body={paidPlansCheckout:{planId},callbacks:{thankYouPageUrl:here()+"?bought=1",postFlowUrl:here()}};
  const d=await post("/_api/redirects-api/v1/redirect-session",body,t);location.href=d.redirectSession.fullUrl}
async function cancel(orderId){const t=await member();if(!t)throw new Error("Sign in first.");
  return post("/pricing-plans/v2/member/orders/"+encodeURIComponent(orderId)+"/cancel",{effectiveAt:"NEXT_PAYMENT_DATE"},t)}
window.TieOutAccount={PLANS,signIn,signInDesktop,aiUsage,teamGet:()=>teamCall("get"),teamRecipes:async(op,extra)=>{const t=await member();if(!t)throw new Error("Sign in first.");const r=await fetch(AI+"/v1/recipes/"+op,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.assign({memberToken:t},extra||{}))});const d=await r.json().catch(()=>({}));if(!r.ok||!d.ok)throw new Error(d.message||"Couldn't reach team recipes. Try again.");return d},teamAdd:e=>teamCall("add",{email:e}),teamRemove:i=>teamCall("remove",{index:i}),finishSignIn,signOut,me,orders,plan,checkout,cancel,token:member,signedIn:()=>!!get(KEY),email:()=>(get(KEY)||{}).email||""};
})();
